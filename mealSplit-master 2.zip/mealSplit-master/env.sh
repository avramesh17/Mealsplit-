export MONGODB_URI=mongodb://hackathon:D5F-Qrn-SGb-emt@ds153958.mlab.com:53958/mealsplit

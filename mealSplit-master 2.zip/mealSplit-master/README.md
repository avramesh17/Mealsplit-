# mealSplit
Make splitting restaurant bills easy
